import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Snakev2 extends PApplet {

//TODO: resetknap
//BUGFIX: 
int score = 0;
String lastMove = "";
public void setup(){
  
  frameRate(10);
  target.newTarget();
  frameRate(10);
  textAlign(CENTER);
  surface.setTitle("snake");
}
snake player = new snake(score+1);
target target = new target(false);
public void draw(){
  background(200);
  switch (key){
  case 'w':
    if(lastMove!="down"){
      player.moveSnakeUp();
      lastMove="up";
  }else{
    player.moveSnakeDown();
  }
    break;
  case 'a':
    if(lastMove!="right"){
      player.moveSnakeLeft();
      lastMove="left";
    }else{
    player.moveSnakeRight();
  }
    break;
  case 's':
    if(lastMove!="up"){
      player.moveSnakeDown();
      lastMove="down";
    }else{
    player.moveSnakeUp();
  }
    break;
  case 'd':
    if(lastMove!="left"){
      player.moveSnakeRight();
      lastMove="right";
    }else{
    player.moveSnakeLeft();
  }
    break;
  }
  target.drawTarget();
  player.drawSnake();
  if(player.collisionWithSelf()||player.collsionWithWall()){
    noLoop();
    textSize(185*width/1000);
    background(200);
    fill(0);
    text("Game Over",width/2,height/2);
    textSize(95);
    text("Score:" + score, width/2,7*height/10);
  }
  if(target.x == player.xs.get(0)+25 && target.y == player.ys.get(0)+25){
  score+=1;
  player.addSize();
  target.newTarget();
  player.size +=1;
  }
}
class snake{
  IntList xs;
  IntList ys;
  int size = 0;{}{
  xs = new IntList();
  ys = new IntList();}
  snake(int size){
    this.size = size;
    if (size==1){
    xs.append(50*floor(random(1000/50)));
    ys.append(50*floor(random(1000/50)));
    }else{
      for(int i = 0; i<size;i++){
      xs.append(50*i);
      ys.append(50);
    }  
    }
  }
  
  
  //tenger slagen 
  public void drawSnake(){
    fill(0,255,0);
    for(int i = 0; i<size;i++){
      rect(xs.get(i),ys.get(i),50,50);   
    }
  }
  
  public void addSize(){
  xs.append(100);
  ys.append(100); 
  }
  
  //flytter slangen de fire retninger
  public void moveSnakeUp(){
    for(int i = ys.size()-1; i > 0;i--){
      ys.set(i,ys.get(i-1));
    }
    ys.sub(0,50);
    for(int i = xs.size()-1; i > 0;i--){
      xs.set(i,xs.get(i-1));
    }
  }
  
  public void moveSnakeRight(){
    for(int i = ys.size()-1; i > 0;i--){
      ys.set(i,ys.get(i-1));
    }
    for(int i = xs.size()-1; i > 0;i--){
      xs.set(i,xs.get(i-1));
    }
    xs.add(0,50);
  }
  
  public void moveSnakeLeft(){
    for(int i = ys.size()-1; i > 0;i--){
      ys.set(i,ys.get(i-1));
    }
    for(int i = xs.size()-1; i > 0;i--){
      xs.set(i,xs.get(i-1));
    }
    xs.sub(0,50);
  }  
  
   public void moveSnakeDown(){
    for(int i = ys.size()-1; i > 0;i--){
      ys.set(i,ys.get(i-1));
    }
    for(int i = xs.size()-1; i > 0;i--){
      xs.set(i,xs.get(i-1));
    }
    ys.add(0,50);
  } 
  
  public boolean collisionWithSelf(){
  for(int i = 1; i<size;i++){
    if(xs.get(0)==xs.get(i)&&ys.get(0)==ys.get(i)){return true;}
  }
    return false;
  }
  public boolean collsionWithWall(){
    if(xs.get(0)>=width || xs.get(0)<0 || ys.get(0)<0||ys.get(0)>=height){return true;}
    return false;
  }
}
class target{
  int x, y;
  boolean exists;
  target(boolean exists){
    this.exists = exists;
  }
  //vælger et nyt sted på gridet at lave et target
  public void newTarget(){
    x = 50*floor(random(width/50))+25;
    y = 50*floor(random(height/50))+25;
  }
  //tegner en rød cirkel ved x,y
  public void drawTarget(){
    fill(255,0,0);
    circle(x,y,50); 
  }
}
  public void settings() {  size(1000,1000); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Snakev2" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
